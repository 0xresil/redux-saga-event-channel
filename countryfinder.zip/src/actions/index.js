import { createAction } from "@reduxjs/toolkit";
export const PUT_COUNTRIES = createAction("PUT_COUNTRIES");