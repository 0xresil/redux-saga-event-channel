
import SideBar from 'components/SideBar.js'

function App() {
  return (
      <SideBar/>
  );
}

export default App;
